/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.mensagem.bean;

import br.com.mensagem.DAO.UserDAO;
import br.com.mensagem.entidade.User;
import java.io.Serializable;
import java.sql.SQLException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

@ManagedBean
@SessionScoped
public class UserBean implements Serializable {

    private User login;

    public UserBean() {
        this.login = new User();
    }

    public User getLogin() {
        return login;
    }

    public void setLogin(User login) {
        this.login = login;
    }

    public String logarNoSistema() throws ClassNotFoundException {

        UserDAO dao = new UserDAO();
        boolean teste = dao.checkLogin(this.login.getLogin(), this.login.getSenha());

        if (teste) {
            HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
            session.setAttribute("user", login);
            return "mensagem.xhtml?faces-redirect=true";
        }
        return "/index.xhtml?faces-redirect=true";
    }

    public String deslogarDoSistema() {
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        return "/index.xhtml?faces-redirect=true";
    }

    public String cadastrar() throws ClassNotFoundException, SQLException {
        new UserDAO().inserir(login);
        return "mensagem.xhtml?faces-redirect=true";
    }

}
