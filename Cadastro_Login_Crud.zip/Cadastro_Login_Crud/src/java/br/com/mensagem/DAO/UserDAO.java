/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.mensagem.DAO;

import br.com.mensagem.entidade.User;
import br.com.mensagem.util.FabricaConexao;
import com.mysql.jdbc.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Davi
 */
public class UserDAO {

    public boolean checkLogin(String login, String senha) throws ClassNotFoundException {

        Connection conexao = (Connection) FabricaConexao.getConexao();
        PreparedStatement pst = null;
        ResultSet rs = null;
        boolean verifica = false;

        try {
            pst = conexao.prepareCall("SELECT * FROM usuario WHERE login = ? and senha = ?");
            pst.setString(1, login);
            pst.setString(2, senha);

            rs = pst.executeQuery();

            if (rs.next()) {
                verifica = true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return verifica;
    }

    public void inserir(User usuario) throws ClassNotFoundException, SQLException {
        try {
            Connection conexao = (Connection) FabricaConexao.getConexao();
            PreparedStatement pst = null;
            if (usuario.getId() == null) {
                pst = conexao.prepareCall("INSERT INTO usuario (id, login, senha)"
                        + " values(null,?,?)");
            }
            
            pst.setString(1, usuario.getLogin());
            pst.setString(2, usuario.getSenha());
            pst.execute();
            FabricaConexao.fecharConexao();
        } catch (SQLException ex) {
            Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
}
