package br.com.controle;

public class Contas {
    private int codigo;
    private double valor;
    private String tipo;
    private String datacadastro;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDatacadastro() {
        return datacadastro;
    }

    public void setDatacadastro(String datanoticia) {
        this.datacadastro = datanoticia;
    }

}
