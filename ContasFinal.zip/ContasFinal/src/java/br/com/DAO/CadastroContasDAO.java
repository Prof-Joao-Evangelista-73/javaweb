package br.com.DAO;

import br.com.controle.Contas;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;

public class CadastroContasDAO extends DAO{
    public void inserir(Contas ms) throws Exception{
        try{
            abrirBanco();
            String query = "INSERT INTO cadastro_contas (codigo, valor, tipo, datacadastro) "
                    + "VALUES (null,?,?,?)";
            pst = (PreparedStatement) con.prepareStatement(query);
            pst.setDouble(1, ms.getValor());
            pst.setString(2, ms.getTipo());
            pst.setDate(3, new java.sql.Date(Calendar.getInstance().getTimeInMillis()));
            pst.execute();
            fecharBanco();
        } catch (Exception e){
            System.out.println("Erro" + e.getMessage());
        }
    }
    
    public ArrayList<Contas> pesquisarTudo () throws Exception {
       ArrayList<Contas> listantc = new ArrayList<Contas>();
         try{
         abrirBanco();  
         String query = "select codigo, valor,  tipo, DATE_FORMAT(datacadastro, '%d/%m/%y') as datacadastro FROM cadastro_contas order by(codigo)desc limit 0,10";
         pst = con.prepareStatement(query);
         ResultSet rs = pst.executeQuery();
         Contas ntcben ;
         while (rs.next()){ 
           ntcben = new Contas();
           ntcben.setCodigo(rs.getInt("codigo"));
           ntcben.setValor(rs.getDouble("valor"));
           ntcben.setTipo(rs.getString("tipo"));
           ntcben.setDatacadastro(rs.getString("datacadastro"));
           listantc.add(ntcben); 
         } 
         fecharBanco();
       }catch (Exception e){
           System.out.println("Erro " + e.getMessage());
     } 
       return listantc;
     }
}

