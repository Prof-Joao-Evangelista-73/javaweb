package br.com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DAO {
    Connection con;
    PreparedStatement pst;
    ResultSet rst;
    
    public void abrirBanco() throws SQLException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/contas";
            String user = "root";
            String senha = "system";
            con = (Connection) DriverManager.getConnection(url,user,senha);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException e){
            System.out.println(e);
            throw new RuntimeException(e);
        }
    }
    
    public void fecharBanco() throws Exception{
        if (pst != null){
            pst.close();
            System.out.println("Execução da Query fechada\n");
        }
    }
    
    
}
