package br.com.DAO;

import java.sql.SQLException;

/**
 *
 * @author ianma
 */
public class Teste {
    public static void main(String[] args) throws SQLException, Exception {
        DAO c = new DAO();
        c.abrirBanco();
        c.fecharBanco();
    }
}
