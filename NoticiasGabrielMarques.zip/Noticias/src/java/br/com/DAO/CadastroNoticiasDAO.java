/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.DAO;

import br.com.controle.Noticias;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author yasmin
 */
public class CadastroNoticiasDAO extends DAO{
     public void inserir(Noticias ms) throws Exception {
    try {
    abrirBanco();
    String query = "INSERT INTO cadastro_noticias (codigo,noticia,datanoticia) "
            + "values(null,?,?)";
    pst=(PreparedStatement) con.prepareStatement(query);
    pst.setString(1, ms.getNoticia());
    pst.setDate(2, new java.sql.Date
    (Calendar.getInstance().getTimeInMillis())); 
    pst.execute();
    fecharBanco();
    } catch (Exception e) {
        System.out.println("Erro " + e.getMessage());
    }
    }
	
	
	public ArrayList<Noticias> pesquisarTudo () throws Exception {
       ArrayList<Noticias> listantc = new ArrayList<Noticias>();
         try{
         abrirBanco();  
         String query = "select * FROM cadastro_noticias order by(codigo)desc";
         pst = con.prepareStatement(query);
         ResultSet rs = pst.executeQuery();
         Noticias ntcben ;
         while (rs.next()){ 
           ntcben = new Noticias();
           ntcben.setCodigo(rs.getInt("codigo"));
           ntcben.setNoticia(rs.getString("noticia"));
           ntcben.setDatanoticia(rs.getDate("datanoticia"));
           listantc.add(ntcben); 
         } 
         fecharBanco();
       }catch (Exception e){
           System.out.println("Erro " + e.getMessage());
     } 
       return listantc;
     }}