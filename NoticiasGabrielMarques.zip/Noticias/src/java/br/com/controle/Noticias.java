/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.controle;

import java.sql.Date;

/**
 *
 * @author yasmin
 */
public class Noticias {
  private int codigo;
  private String noticia;
  private Date datanoticia;

  
    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
    public String getNoticia() {
        return noticia;
    }

    public void setNoticia(String noticia) {
        this.noticia = noticia;
    }
    
    public Date getDatanoticia() {
        return datanoticia ;
    }
    public void setDatanoticia(Date datanoticia ) {
        this.datanoticia  = datanoticia ;
    }    
}