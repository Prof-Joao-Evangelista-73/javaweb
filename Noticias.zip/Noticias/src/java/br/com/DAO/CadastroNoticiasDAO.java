/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.DAO;

import br.com.controle.Noticias;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author yasmin
 */
public class CadastroNoticiasDAO extends DAO{
     public void inserir(Noticias ms) throws Exception {
    try {
    abrirBanco();
    String query = "INSERT INTO cadastro_noticias (codigo,noticia,valor,datanoticia) "
            + "values(null,?,?,?)";
    pst=(PreparedStatement) con.prepareStatement(query);
    pst.setString(1, ms.getNoticia());
    pst.setDouble(2,ms.getValor());
    pst.setDate(3, new java.sql.Date
    (Calendar.getInstance().getTimeInMillis())); 
    pst.execute();
    fecharBanco();
    } catch (Exception e) {
        System.out.println("Erro " + e.getMessage());
    }
    }

	public ArrayList<Noticias> pesquisarTudo () throws Exception {
       ArrayList<Noticias> listantc = new ArrayList<Noticias>();
         try{
         abrirBanco();  
         String query = "select  codigo,noticia,valor, DATE_FORMAT(datanoticia,'%d/%m/%Y') AS datanoticia FROM cadastro_noticias order by(codigo)desc limit 0,5";
         //Problemaa da data reolvido aqui com recuroso do sql
         pst = con.prepareStatement(query);
         ResultSet rs = pst.executeQuery();
         Noticias ntcben ;
         while (rs.next()){ 
           ntcben = new Noticias();
           ntcben.setCodigo(rs.getInt("codigo"));
           ntcben.setNoticia(rs.getString("noticia"));
           ntcben.setValor(rs.getDouble("valor"));
           ntcben.setDatanoticia(rs.getString("datanoticia"));
           listantc.add(ntcben); 
         } 
         fecharBanco();
       }catch (Exception e){
           System.out.println("Erro " + e.getMessage());
     } 
       return listantc;
     }

        
         public void deletar(Noticias nt) throws Exception{
         abrirBanco();
         String query = "delete FROM cadastro_noticias where codigo=?";
         pst=(PreparedStatement) con.prepareStatement(query);
         pst.setInt(1, nt.getCodigo());
         pst.execute();
        fecharBanco();   
     }
         public void alterar(Noticias nt) throws Exception {
		try {
    abrirBanco();
    String query = "UPDATE cadastro_noticias SET noticia=?,valor=? WHERE codigo=?;";
    pst = con.prepareStatement(query);
    pst.setString(1, nt.getNoticia());
    pst.setDouble(2, nt.getValor());
    pst.setInt(3, nt.getCodigo());
    pst.executeUpdate();
    fecharBanco();
			
    } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
    }
	}

      public Noticias pesquisar(int id) throws Exception {
    try {
            Noticias nt = new Noticias();
            System.out.println(" Chegou no pesquisar registo" + id);
            abrirBanco();
            String query = "select * FROM cadastro_noticias where codigo=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                nt.setCodigo(rs.getInt("codigo"));
                nt.setNoticia(rs.getString("noticia"));
                nt.setValor(rs.getDouble("valor"));
                nt.setDatanoticia(rs.getString("datanoticia"));
                return nt;
            }
            fecharBanco();
    } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
    }
    return null;
	}   
         
         
}