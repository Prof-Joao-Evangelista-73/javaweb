/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.controle;

/**
 *
 * @author yasmin
 */
public class Noticias {
  private int codigo;
  private String noticia;
  private double valor;

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
  private String datanoticia;

  
    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
    public String getNoticia() {
        return noticia;
    }

    public void setNoticia(String noticia) {
        this.noticia = noticia;
    }
    
    public String getDatanoticia() {
        return datanoticia ;
    }
    public void setDatanoticia(String datanoticia ) {
        this.datanoticia  = datanoticia ;
    }    
}