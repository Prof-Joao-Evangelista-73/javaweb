/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.professor.DAO;

import br.com.escola.util.FabricaConexao;
import br.com.professor.entidade.Professor;
import java.sql.PreparedStatement;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLDataException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProfessorDAO {
    
    public void inserir(Professor p) throws ClassNotFoundException, SQLDataException {
        try{
        Connection conexao = FabricaConexao.getConexao();
            PreparedStatement pst;
             if (p.getMatricula()== null) {
            pst=conexao.prepareCall ("insert into professor (matricula, nome, email, idade) values(null,?,?,?)");
             }else {
                pst = conexao.prepareCall("UPDATE professor set nome=?, email=?, idade=? where matricula=?");
                pst.setInt(4, p.getMatricula());
            }    
            pst.setString(1, p.getNome());
            pst.setString(2, p.getEmail());
            pst.setInt(3, p.getIdade());
            pst.execute();
            FabricaConexao.fecharConexao();
            
        
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }
    
    public List <Professor> selecionarTudo() throws ClassNotFoundException, SQLException{
      try {
    Connection conexao = FabricaConexao.getConexao();
    PreparedStatement pst=conexao.prepareCall("SELECT * FROM professor");
    ResultSet rs = pst.executeQuery();
    List<Professor> lista = new ArrayList<>();
    while(rs.next()){
      Professor pr= new Professor();
      pr.setMatricula(rs.getInt("matricula"));
      pr.setNome(rs.getString("nome"));
      pr.setEmail(rs.getString("email"));
      pr.setIdade(rs.getInt("idade"));
      lista.add(pr);
    } 
           return lista;
      }catch (SQLException ex) {
          Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE,null,ex);
      }   
      return null;
     
   }
    
    public void deletar(Professor p ) throws  ClassNotFoundException,SQLException{
     try{
         Connection connexao=(Connection) FabricaConexao.getConexao();
         PreparedStatement pst;
         if(p.getMatricula()>0){
         pst=connexao.prepareCall("DELETE FROM professor WHERE matricula=?;");
         pst.setInt(1,p.getMatricula());
         pst.execute();
     }
         FabricaConexao.fecharConexao();
     }catch(SQLException ex){
         Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE,null,ex);
     }
     
   }
    
}
