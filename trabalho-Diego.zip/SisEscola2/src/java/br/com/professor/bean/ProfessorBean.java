package br.com.professor.bean;

import br.com.professor.DAO.ProfessorDAO;
import br.com.professor.entidade.Professor;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class ProfessorBean {
    private Professor professor = new Professor();
    private ProfessorDAO prof_dao = new ProfessorDAO();
    private List<Professor>lista_professor = new ArrayList<>();

   
    
    public void cadastrar() throws ClassNotFoundException, SQLException{
    
        new ProfessorDAO().inserir(professor);
        professor= new Professor();
        lista_professor=prof_dao.selecionarTudo();
    }
    
    public void deletar(Professor prof) throws ClassNotFoundException,SQLException{
        new ProfessorDAO().deletar(prof);
        listar();
    }
    
    
    
    public void listar() throws ClassNotFoundException, SQLException{
     lista_professor=prof_dao.selecionarTudo();
    }
  public void alterar(Professor p){
        professor = p;
   }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public ProfessorDAO getProf_dao() {
        return prof_dao;
    }

    public void setProf_dao(ProfessorDAO prof_dao) {
        this.prof_dao = prof_dao;
    }
    
     public List<Professor> getLista_professor() {
        return lista_professor;
    }

    public void setLista_professor(List<Professor> lista_professor) {
        this.lista_professor = lista_professor;
    }
}
