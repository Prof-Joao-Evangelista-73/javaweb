/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.usuario.bean;

import br.com.usuario.DAO.UsuarioDAO;
import br.com.usuario.entidade.Usuario;
import java.sql.SQLException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class UsuarioBean {
    
    private Usuario usuario = new Usuario();
    private UsuarioDAO usu_dao = new UsuarioDAO();
    
    public void cadastrar() throws ClassNotFoundException, SQLException{
    
        new UsuarioDAO().inserir(usuario);
        usuario= new Usuario();
        
    }

    public UsuarioDAO getUsu_dao() {
        return usu_dao;
    }

    public void setUsu_dao(UsuarioDAO usu_dao) {
        this.usu_dao = usu_dao;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
}
