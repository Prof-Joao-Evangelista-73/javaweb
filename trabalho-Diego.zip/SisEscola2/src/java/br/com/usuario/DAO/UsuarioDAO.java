/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.usuario.DAO;

import br.com.escola.util.FabricaConexao;
import br.com.usuario.entidade.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLDataException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author diego
 */
public class UsuarioDAO {
    public void inserir(Usuario u) throws ClassNotFoundException, SQLDataException, SQLException{
     try {
    Connection conexao = FabricaConexao.getConexao();
    PreparedStatement pst;
    
    pst=conexao.prepareCall ("INSERT INTO Users (uid,uname,password) values(null,?,?)");
    
    
    pst.setString(1, u.getUsuario());
    pst.setString(2, u.getSenha());
    pst.execute();  
    FabricaConexao.fecharConexao();
      } catch (SQLException ex) {
           Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE,null,ex);
      }
    
    }
}
