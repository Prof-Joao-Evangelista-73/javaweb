/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.disciplina.bean;

import br.com.disciplina.DAO.DisciplinaDAO;
import br.com.disciplina.entidade.Disciplina;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Diego
 */
@ManagedBean
@SessionScoped
public class DisciplinaBean {

    
    private Disciplina disciplina = new Disciplina();
    private DisciplinaDAO dis_dao = new DisciplinaDAO();
    private List<Disciplina>lista_disciplina= new ArrayList<>();
    
    public void cadastrar() throws ClassNotFoundException, SQLException{
    
        new DisciplinaDAO().inserir(disciplina);
        disciplina= new Disciplina();
        lista_disciplina=dis_dao.selecionarTudo();
    }
    
    public void deletar(Disciplina d) throws ClassNotFoundException,SQLException{
        new DisciplinaDAO().deletar(d);
        listar();
    }
    
   public void listar() throws ClassNotFoundException, SQLException{
     lista_disciplina=dis_dao.selecionarTudo();
   }
   
   public void alterar(Disciplina d){
       disciplina = d;
   }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    public DisciplinaDAO getDis_dao() {
        return dis_dao;
    }

    public void setDis_dao(DisciplinaDAO dis_dao) {
        this.dis_dao = dis_dao;
    }
    
    public List<Disciplina> getLista_disciplina() {
        return lista_disciplina;
    }

    public void setLista_disciplina(List<Disciplina> lista_disciplina) {
        this.lista_disciplina = lista_disciplina;
    }
}
