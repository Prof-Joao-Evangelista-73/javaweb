/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.disciplina.DAO;

import br.com.disciplina.entidade.Disciplina;
import br.com.escola.util.FabricaConexao;
import com.mysql.jdbc.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Diego
 */
public class DisciplinaDAO {
    public void inserir(Disciplina d) throws ClassNotFoundException, SQLException{
    try{
     Connection conexao = FabricaConexao.getConexao();
     PreparedStatement pst;
     if (d.getCodigo()== null) {
     pst=conexao.prepareCall("insert into disciplina (codigo,nome) values(null,?)");
     } else{ pst = conexao.prepareCall("UPDATE disciplina set nome=? where codigo=?");
                pst.setInt(2, d.getCodigo());
     }
     pst.setString(1, d.getNome());
     pst.execute();
     FabricaConexao.fecharConexao();
    }catch (SQLException ex){ 
        Logger.getLogger(DisciplinaDAO.class.getName()).log(Level.SEVERE,null,ex);
    }
    
    }
    
    public List <Disciplina> selecionarTudo() throws ClassNotFoundException, SQLException{
      try {
    Connection conexao = FabricaConexao.getConexao();
    PreparedStatement pst=conexao.prepareCall("SELECT * FROM disciplina");
    ResultSet rs = pst.executeQuery();
    List<Disciplina> lista = new ArrayList<>();
    while(rs.next()){
      Disciplina d= new Disciplina();
      d.setCodigo(rs.getInt("codigo"));
      d.setNome(rs.getString("nome"));
      
      lista.add(d);
    } 
           return lista;
      }catch (SQLException ex) {
          Logger.getLogger(DisciplinaDAO.class.getName()).log(Level.SEVERE,null,ex);
      }   
      return null;
     
   }
    
    public void deletar(Disciplina d) throws  ClassNotFoundException,SQLException{
     try{
         Connection connexao=(Connection) FabricaConexao.getConexao();
         PreparedStatement pst;
         if(d.getCodigo()>0){
         pst=connexao.prepareCall("DELETE FROM disciplina WHERE codigo=?;");
         pst.setInt(1,d.getCodigo());
         pst.execute();
     }
         FabricaConexao.fecharConexao();
     }catch(SQLException ex){
         Logger.getLogger(DisciplinaDAO.class.getName()).log(Level.SEVERE,null,ex);
     }
     
   }
}
