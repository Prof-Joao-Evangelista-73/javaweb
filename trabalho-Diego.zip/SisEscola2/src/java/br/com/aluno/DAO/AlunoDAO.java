package br.com.aluno.DAO;

import br.com.aluno.entidade.Aluno;
import br.com.escola.util.FabricaConexao;
import com.mysql.jdbc.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AlunoDAO {
public void inserir(Aluno a) throws ClassNotFoundException, SQLException{
      try {
    Connection conexao = FabricaConexao.getConexao();
    PreparedStatement pst;
    if (a.getCodigo() == null) {
    pst=conexao.prepareCall ("INSERT INTO aluno (codigo,nome,email) values(null,?,?)");
    }else {
                pst = conexao.prepareCall("UPDATE aluno set nome=?, email=? where codigo=?");
                pst.setInt(3, a.getCodigo());
            }    
    pst.setString(1, a.getNome());
    pst.setString(2, a.getEmail());
    pst.execute();  
    FabricaConexao.fecharConexao();
      } catch (SQLException ex) {
           Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE,null,ex);
      }
   
  }


 public List <Aluno> selecionarTudo() throws ClassNotFoundException, SQLException{
      try {
    Connection conexao = FabricaConexao.getConexao();
    PreparedStatement pst=conexao.prepareCall("SELECT * FROM aluno");
    ResultSet rs = pst.executeQuery();
    List<Aluno> lista = new ArrayList<>();
    while(rs.next()){
      Aluno al= new Aluno();
      al.setCodigo(rs.getInt("codigo"));
      al.setNome(rs.getString("nome"));
      al.setEmail(rs.getString("email"));
      lista.add(al);
    } 
           return lista;
      }catch (SQLException ex) {
          Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE,null,ex);
      }   
      return null;
     
   }
  public void deletar(Aluno a) throws  ClassNotFoundException,SQLException{
     try{
         Connection connexao=(Connection) FabricaConexao.getConexao();
         PreparedStatement pst;
         if(a.getCodigo()>0){
         pst=connexao.prepareCall("DELETE FROM aluno WHERE codigo=?;");
         pst.setInt(1,a.getCodigo());
         pst.execute();
     }
         FabricaConexao.fecharConexao();
     }catch(SQLException ex){
         Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE,null,ex);
     }
     
   }
    
}
