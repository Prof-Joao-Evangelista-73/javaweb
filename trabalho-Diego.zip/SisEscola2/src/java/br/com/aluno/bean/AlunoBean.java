
package br.com.aluno.bean;

import br.com.aluno.DAO.AlunoDAO;
import br.com.aluno.entidade.Aluno;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.model.SelectItem;

@ManagedBean
@SessionScoped
public class AlunoBean {
    
    private Aluno aluno = new Aluno();//objeto que herda os metodos get e set da classe Aluno
  private AlunoDAO alu_dao =new AlunoDAO();//objeto que herda os metodos inserir deletar e listar e excluir da 
 //da classe MensagemDAO
  private List<Aluno>lista_aluno = new ArrayList<>();

  public void cadastrar() throws ClassNotFoundException, SQLException{
       // getMsg_dao().inserir(getMensagem());//executando o metodo inserir da classe DAO
       // setMensagem(new Mensagem());//passando o objeto mensagem para limpar a memoria
        new AlunoDAO().inserir(aluno);
        aluno=new Aluno();
        lista_aluno=alu_dao.selecionarTudo();
     }  
   public void deletar(Aluno al) throws ClassNotFoundException,SQLException{
        new AlunoDAO().deletar(al);
        listar();
    }
  
   
   
   
   public void listar() throws ClassNotFoundException, SQLException{
     lista_aluno=alu_dao.selecionarTudo();
    }
   
   public void alterar(Aluno a){
        aluno = a;
   }
  
   public Aluno getAluno() {
        return aluno;
    }
    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }
    public AlunoDAO getAluno_dao() {
        return alu_dao;
    }
    public void setAluno_dao(Aluno aluno_dao) {
        this.alu_dao = alu_dao;
    }

    public List<Aluno> getListaluno() {
        return lista_aluno;
    }

    public void setListaluno(List<Aluno> lista_aluno) {
        this.lista_aluno = lista_aluno;
    }
  
    
}
