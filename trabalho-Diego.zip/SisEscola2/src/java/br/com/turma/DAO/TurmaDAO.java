/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.turma.DAO;

import br.com.escola.util.FabricaConexao;
import br.com.turma.entidade.Turma;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLDataException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Diego
 */
public class TurmaDAO {
    public void inserir(Turma t) throws ClassNotFoundException, SQLDataException, SQLException{
     try {
    Connection conexao = FabricaConexao.getConexao();
    PreparedStatement pst;
    
    pst=conexao.prepareCall ("INSERT INTO turma (codigo,cod_aluno,cod_professor,cod_disciplina) values(null,?,?,?)");
    
    pst.setInt(1, t.getCod_aluno());
    pst.setInt(2, t.getCod_prof());
    pst.setInt(3, t.getCod_disc());
    pst.execute();  
    FabricaConexao.fecharConexao();
      } catch (SQLException ex) {
           Logger.getLogger(TurmaDAO.class.getName()).log(Level.SEVERE,null,ex);
      }
    
    }
    
    public List <Turma> selecionarTudo() throws ClassNotFoundException, SQLException{
      try {
    Connection conexao = FabricaConexao.getConexao();
    PreparedStatement pst=conexao.prepareCall("select a.nome aluno, p.nome professor, d.nome disciplina from aluno a, professor p, disciplina d, turma t "
            + "where  t.cod_aluno = a.codigo and t.cod_professor = p.matricula and t.cod_disciplina = d.codigo");
    ResultSet rs = pst.executeQuery();
    List<Turma> lista = new ArrayList<>();
    while(rs.next()){
      Turma t= new Turma();
      t.setAluno(rs.getString("aluno"));
      t.setProfessor(rs.getString("professor"));
      t.setDiscipĺina(rs.getString("disciplina"));
      
      lista.add(t);
    } 
           return lista;
      }catch (SQLException ex) {
          Logger.getLogger(TurmaDAO.class.getName()).log(Level.SEVERE,null,ex);
      }   
      return null;
     
   }
}
