/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.turma.bean;

import br.com.aluno.DAO.AlunoDAO;
import br.com.aluno.entidade.Aluno;
import br.com.disciplina.DAO.DisciplinaDAO;
import br.com.disciplina.entidade.Disciplina;
import br.com.professor.DAO.ProfessorDAO;
import br.com.professor.entidade.Professor;
import br.com.turma.DAO.TurmaDAO;
import br.com.turma.entidade.Turma;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.model.SelectItem;

/**
 *
 * @author Diego
 */
@ManagedBean
@SessionScoped
public class TurmaBean {
    Aluno aluno = new Aluno();
    AlunoDAO alu_dao =new AlunoDAO();
    Professor professor = new Professor();
    ProfessorDAO prof_dao = new ProfessorDAO();
    Disciplina disciplina = new Disciplina();
    DisciplinaDAO dis_dao = new DisciplinaDAO();
    TurmaDAO tur_dao = new TurmaDAO();

    
    
    private Turma turma = new Turma();
    private TurmaDAO turma_dao= new TurmaDAO();
    private List<Turma>lista_turma = new ArrayList<>();

    
    
    public void cadastrar() throws ClassNotFoundException, SQLException{
    
        new TurmaDAO().inserir(turma);
        turma= new Turma();
        lista_turma=tur_dao.selecionarTudo();
    }
    
    public void listar() throws ClassNotFoundException, SQLException{
     lista_turma=tur_dao.selecionarTudo();
    }
    
    public List<SelectItem> getAlunos() throws ClassNotFoundException, SQLException {//classe SecltItem puxa os dados
          ArrayList<SelectItem> itens = new ArrayList<SelectItem>();
          List<Aluno> resultado = alu_dao.selecionarTudo();
          for (Aluno a : resultado)
            itens.add(new SelectItem(a.getCodigo(), a.getNome()));
          return itens;
    }
    
    public List<SelectItem> getCodAlunos() throws ClassNotFoundException, SQLException {//classe SecltItem puxa os dados
          ArrayList<SelectItem> itens = new ArrayList<SelectItem>();
          List<Aluno> resultado = alu_dao.selecionarTudo();
          for (Aluno a : resultado)
            itens.add(new SelectItem(a.getCodigo()));
          return itens;
    }
    
    public List<SelectItem> getProfessores() throws ClassNotFoundException, SQLException {//classe SecltItem puxa os dados
          ArrayList<SelectItem> itens = new ArrayList<SelectItem>();
          List<Professor> resultado = prof_dao.selecionarTudo();
          for (Professor p : resultado)
            itens.add(new SelectItem(p.getMatricula(), p.getNome()));
          return itens;
    }
    
    public List<SelectItem> getDisciplinas() throws ClassNotFoundException, SQLException {//classe SecltItem puxa os dados
          ArrayList<SelectItem> itens = new ArrayList<SelectItem>();
          List<Disciplina> resultado = dis_dao.selecionarTudo();
          for (Disciplina d : resultado)
            itens.add(new SelectItem(d.getCodigo(), d.getNome()));
          return itens;
    }
    
    
    public Turma getTurma() {
        return turma;
    }

    public void setTurma(Turma turma) {
        this.turma = turma;
    }
    
     public TurmaDAO getTurma_dao() {
        return turma_dao;
    }

    public void setTurma_dao(TurmaDAO turma_dao) {
        this.turma_dao = turma_dao;
    }
    
    public List<Turma> getLista_turma() {
        return lista_turma;
    }

    public void setLista_turma(List<Turma> lista_turma) {
        this.lista_turma = lista_turma;
    }
}
