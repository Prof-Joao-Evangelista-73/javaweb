/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.turma.entidade;

/**
 *
 * @author Diego
 */
public class Turma {
    
    private Integer codio;
    private Integer cod_aluno;
    private Integer cod_prof;
    private Integer cod_disc;
    private String aluno;
    private String professor;
    private String discipĺina;

    public String getAluno() {
        return aluno;
    }

    public void setAluno(String aluno) {
        this.aluno = aluno;
    }

    public String getProfessor() {
        return professor;
    }

    public void setProfessor(String professor) {
        this.professor = professor;
    }

    public String getDiscipĺina() {
        return discipĺina;
    }

    public void setDiscipĺina(String discipĺina) {
        this.discipĺina = discipĺina;
    }

    public Integer getCodio() {
        return codio;
    }

    public void setCodio(Integer codio) {
        this.codio = codio;
    }

    public Integer getCod_aluno() {
        return cod_aluno;
    }

    public void setCod_aluno(Integer cod_aluno) {
        this.cod_aluno = cod_aluno;
    }

    public Integer getCod_prof() {
        return cod_prof;
    }

    public void setCod_prof(Integer cod_prof) {
        this.cod_prof = cod_prof;
    }

    public Integer getCod_disc() {
        return cod_disc;
    }

    public void setCod_disc(Integer cod_disc) {
        this.cod_disc = cod_disc;
    }
    
}
