package br.com.module;

import br.com.controle.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class UsuarioDAO {
   private Connection con;

    public UsuarioDAO(Connection con) { // metodo para utilizar a conexao
        this.con = con;
    }

    public void adicionar(Usuario u) throws SQLException {

        String sql = "insert into usuario(email,senha)"
                + "values(?,?)";
        try {
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, u.getEmail());
            stmt.setString(2, u.getSenha());

            stmt.execute();
            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            con.close();
        }
    } 
    
    public ArrayList<Usuario> pesquisarTudo () throws Exception {
       ArrayList<Usuario> listamsg = new ArrayList<Usuario>();
         try{
         
         String query = "select * FROM usuario order by(codigo)desc limit 0,10";
         PreparedStatement stmt = con.prepareStatement(query);
         ResultSet rs = stmt.executeQuery();
         Usuario u_ben ;
         while (rs.next()){ 
           u_ben = new Usuario();
           u_ben.setCodigo(rs.getInt("codigo"));
            u_ben.setEmail(rs.getString("email"));
             u_ben.setSenha(rs.getString("senha"));
           listamsg.add(u_ben); 
         } 
        con.close();
       }catch (Exception e){
           System.out.println("Erro " + e.getMessage());
     } 
       return listamsg;
     }
}
