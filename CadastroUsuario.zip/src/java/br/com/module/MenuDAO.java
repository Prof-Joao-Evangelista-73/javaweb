package br.com.module;

import br.com.controle.Menu;
import br.com.controle.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MenuDAO {

private Connection con;

    public MenuDAO(Connection con) { // metodo para utilizar a conexao
        this.con = con;
    }

    public void adicionar(Menu m) throws SQLException {

        String sql = "insert into menu(menu,link)"
                + "values(?,?)";
        try {
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, m.getMenu());
            stmt.setString(2, m.getLink());

            stmt.execute();
            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            con.close();
        }
    } 
    
    public ArrayList<Menu> pesquisarTudo () throws Exception {
       ArrayList<Menu> listam = new ArrayList<Menu>();
         try{
         
         String query = "select * FROM menu order by(idmenu)desc limit 0,10";
         PreparedStatement stmt = con.prepareStatement(query);
         ResultSet rs = stmt.executeQuery();
         Menu u_menu ;
         while (rs.next()){ 
           u_menu = new Menu();
           u_menu.setIdmenu(rs.getInt("idmenu"));
            u_menu.setLink(rs.getString("menu"));
             u_menu.setMenu(rs.getString("link"));
           listam.add(u_menu); 
         } 
        con.close();
       }catch (Exception e){
           System.out.println("Erro " + e.getMessage());
     } 
       return listam;
     }    
}
